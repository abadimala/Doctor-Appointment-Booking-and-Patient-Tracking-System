Contributions from Individual team members:

Features:

1) Register and Login:
Contributors: Vishnu Prasath Muthukumarasamy,
Srikrushna Pinaki Budi,
Apoorva Gerasa Shankarappa Gowda

2) Appointment Scheduling:
Contributors: Vishnu Prasath Muthukumarasamy,
Srikrushna Pinaki Budi

3) Appointment Cancellation and availability:
Contributors: Apoorva Gerasa Shankarappa Gowda

4) Doctor Profile and Medical History:
Contributors: Srikrushna Pinaki Budi,
Apoorva Gerasa Shankarappa Gowda

5) Doctor Ratings and reviews:
Contributors: Vishnu Prasath Muthukumarasamy

6) UI/UX:
Contributors: Priyanka Bengaluru Anil

7) Documentation:
Contributors: Priyanka Bengaluru Anil,
Amuktha Badimala

8) Validation:
Contributors: Vishnu Prasath Muthukumarasamy,
Srikrushna Pinaki Budi,
Apoorva Gerasa Shankarappa Gowda

9) View Logged in User Information:
Contributors: Srikrushna Pinaki Budi
