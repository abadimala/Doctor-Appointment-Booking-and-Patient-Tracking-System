// src/components/Layout/Footer.js
import React from 'react';

const Footer = () => {
  return (
    <footer>
      <p></p>
    </footer>
  );
};

export default Footer;
